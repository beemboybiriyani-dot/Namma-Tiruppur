package com.namma.perumanallur

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.auth.FirebaseAuth
import android.util.Base64
import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.Image
import java.io.InputStream

private val Navy=Color(0xFF123B7A); private val Sky=Color(0xFF19A8D8); private val Bg=Color(0xFFF7F9FC)
private val cats=listOf("🚨  அவசர உதவி","💼  வேலை வாய்ப்புகள்","🚗  வாடகை வாகனங்கள்","📍  கடை அமைந்திருக்கும் இடம்","🏛️  அரசு அலுவலகங்கள் அமைந்திருக்கும் இடம்","📢  நம்ம ஊர் நிகழ்வுகள்")

class MainActivity:ComponentActivity(){ override fun onCreate(b:Bundle?){super.onCreate(b); FirebaseApp.initializeApp(this); setContent{App()}} }

@Composable fun App(){ var logged by remember{mutableStateOf(FirebaseAuth.getInstance().currentUser!=null)}; var screen by remember{mutableStateOf("home")}; if(!logged) Login{logged=true}else Surface(color=Bg){ when(screen){"home"->Home({screen="ads"},{screen="category"});"ads"->Ads({screen="adsubmit"},{screen="home"});"adsubmit"->AdSubmit{screen="ads"};"category"->Category{screen="home"};else->Home({screen="ads"},{screen="category"}) } } }

@Composable fun Login(done:()->Unit){var email by remember{mutableStateOf("")};var pass by remember{mutableStateOf("")};var msg by remember{mutableStateOf("")};var create by remember{mutableStateOf(false)};Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.Center){Text("நம்ம திருப்பூர்",fontSize=32.sp,fontWeight=FontWeight.Bold,color=Navy);Text("மாவட்ட மக்களுக்கான உள்ளூர் தகவல் தளம்",color=Color.Gray);Spacer(Modifier.height(24.dp));OutlinedTextField(email,{email=it},label={Text("Email")},singleLine=true,modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(10.dp));OutlinedTextField(pass,{pass=it},label={Text("Password")},singleLine=true,modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(16.dp));Button(onClick={if(create) FirebaseAuth.getInstance().createUserWithEmailAndPassword(email,pass).addOnSuccessListener{done()}.addOnFailureListener{msg="Account creation failed"} else FirebaseAuth.getInstance().signInWithEmailAndPassword(email,pass).addOnSuccessListener{done()}.addOnFailureListener{msg="Login failed"}},modifier=Modifier.fillMaxWidth()){Text(if(create) "Create account" else "Login")};TextButton(onClick={create=!create}){Text(if(create) "Already have an account? Login" else "Create account")};TextButton(onClick={FirebaseAuth.getInstance().sendPasswordResetEmail(email)}){Text("Forgot password?")};if(msg.isNotEmpty())Text(msg,color=MaterialTheme.colorScheme.error)} }

@Composable fun Header(title:String,onBack:(()->Unit)?=null){Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){if(onBack!=null)IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)};Text(title,fontSize=23.sp,fontWeight=FontWeight.Bold,color=Navy)}}
@Composable fun Home(openAds:()->Unit,openCategory:()->Unit){LazyColumn(Modifier.fillMaxSize()){item{Header("நம்ம திருப்பூர்");OutlinedTextField("",{},placeholder={Text("🔎 கடை, வேலை, வாகனம், அரசு அலுவலகம்...")},modifier=Modifier.fillMaxWidth().padding(horizontal=16.dp),singleLine=true);Spacer(Modifier.height(10.dp));Text("📍 தற்போதைய பகுதி",fontWeight=FontWeight.SemiBold,modifier=Modifier.padding(16.dp));Text("திருப்பூர் மாவட்டம்",color=Color.Gray,modifier=Modifier.padding(horizontal=16.dp));Spacer(Modifier.height(8.dp))};items(cats){c->Card(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=6.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color.White),onClick=openCategory){Row(Modifier.padding(18.dp),verticalAlignment=Alignment.CenterVertically){Text(c,fontSize=18.sp,fontWeight=FontWeight.SemiBold);Spacer(Modifier.weight(1f));Icon(Icons.Default.ChevronRight,null,tint=Navy)}}};item{Spacer(Modifier.height(10.dp));Card(Modifier.fillMaxWidth().padding(16.dp),onClick=openAds,colors=CardDefaults.cardColors(containerColor=Sky)){Text("📢 விளம்பரங்கள்",color=Color.White,fontWeight=FontWeight.Bold,fontSize=18.sp,modifier=Modifier.padding(20.dp))};Text("முக்கிய அறிவிப்புகள்",fontWeight=FontWeight.Bold,fontSize=19.sp,modifier=Modifier.padding(16.dp))}}}

@Composable fun Ads(openSubmit:()->Unit,back:()->Unit){Column(Modifier.fillMaxSize()){Header("📢 விளம்பரங்கள்",back);Text("₹5 • 1 நாள்",fontWeight=FontWeight.Bold,color=Navy,modifier=Modifier.padding(horizontal=16.dp));Text("UPI மூலம் பணம் செலுத்தி விளம்பரத்தை சமர்ப்பிக்கலாம்.",color=Color.Gray,modifier=Modifier.padding(16.dp));Button(onClick=openSubmit,modifier=Modifier.fillMaxWidth().padding(16.dp)){Text("₹5 விளம்பரம் சமர்ப்பிக்க")}}}

@Composable fun AdSubmit(back:()->Unit){var title by remember{mutableStateOf("")};var desc by remember{mutableStateOf("")};var qr by remember{mutableStateOf<String?>(null)};var upi by remember{mutableStateOf("8220842719@ptyes")};LaunchedEffect(Unit){FirebaseFirestore.getInstance().collection("appConfig").document("payment").get().addOnSuccessListener{d->upi=d.getString("upiId")?:upi;qr=d.getString("qrBase64")}};Column(Modifier.fillMaxSize()){Header("₹5 விளம்பரம்",back);OutlinedTextField(title,{title=it},label={Text("விளம்பர தலைப்பு")},modifier=Modifier.fillMaxWidth().padding(16.dp));OutlinedTextField(desc,{desc=it},label={Text("விளக்கம்")},modifier=Modifier.fillMaxWidth().padding(horizontal=16.dp));Text("UPI: $upi",fontWeight=FontWeight.Bold,modifier=Modifier.padding(16.dp));if(qr!=null){val bytes=Base64.decode(qr,Base64.DEFAULT);val bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.size);Image(bmp.asImageBitmap(),"QR",Modifier.size(240.dp).align(Alignment.CenterHorizontally))}else{val input:InputStream=LocalContext.current.assets.open("default_qr.jpg");val bmp=BitmapFactory.decodeStream(input);Image(bmp.asImageBitmap(),"QR",Modifier.size(240.dp).align(Alignment.CenterHorizontally))};Button(onClick={FirebaseFirestore.getInstance().collection("ads").add(mapOf("title" to title,"description" to desc,"paymentAmount" to 5,"status" to "PENDING","ownerUid" to FirebaseAuth.getInstance().currentUser?.uid,"createdAt" to System.currentTimeMillis()))},modifier=Modifier.fillMaxWidth().padding(16.dp)){Text("Payment செய்த பிறகு Submit")}}}

@Composable fun Category(back:()->Unit){Column(Modifier.fillMaxSize()){Header("தகவல்கள்",back);Text("Admin approval பெற்ற தகவல்கள் இங்கே காட்டப்படும்.",color=Color.Gray,modifier=Modifier.padding(16.dp));Text("Search மற்றும் பகுதி filter அடுத்த கட்ட data integration-ல் செயல்படும்.",modifier=Modifier.padding(16.dp))}}
